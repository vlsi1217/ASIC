#ifndef _MYPLI_H_
#define _MYPLI_H_
int	mypli_reset_call	(void);
int	mypli_cycle_call	(void);
int	mypli_getcount_call	(void);
int	mypli_setmodulo_call	(void);
#endif
