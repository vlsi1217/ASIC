#ifndef _PLIREAD_H_
#define _PLIREAD_H_
int     pliopen_call        (void);
int     pliread_call        (void);
int     pliclose_call     (void);
#endif
